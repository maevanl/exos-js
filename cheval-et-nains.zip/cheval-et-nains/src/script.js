while (true) {
    var cheval = prompt("Quelle est la couleur du cheval blanc d'Henri IV?");
    if (cheval === 'blanc') {
        break;
    }
    alert("N'importe quoi! Réessaye!");
}
var nain = prompt("Combien y a-t-il de sept nains?");
  if(nain === '7'){
    alert("bravo!")
  }
  else{
    alert("Réfléchis un peu...")
  }